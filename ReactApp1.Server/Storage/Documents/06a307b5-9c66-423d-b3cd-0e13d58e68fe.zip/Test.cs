﻿using System;
using Zadania;

class Program
{
    static void Main()
    {
        /*/
              MagazynLIFO mStos = new MagazynLIFO("Magazyn Testowy");

              mStos.Umiesc(new Paczka("nadawcaA", 5));
              mStos.Umiesc(new Paczka("nadawcaB", 8));
              mStos.Umiesc(new Paczka("nadawcaC", 3));
              mStos.Umiesc(new Paczka("nadawcaD", 10));

              Paczka biezaca = mStos.PodajBiezacy();
              Console.WriteLine("Bieżąca paczka do pobrania:");
              Console.WriteLine(biezaca);
              Console.WriteLine();

              Console.WriteLine("Zawartość magazynu przed pobraniem:");
              Console.WriteLine(mStos);

              Paczka pobrana = mStos.Pobierz();
              Console.WriteLine("Pobrano paczkę:");
              Console.WriteLine(pobrana);
              Console.WriteLine();

              Console.WriteLine("Zawartość magazynu po pobraniu:");
              Console.WriteLine(mStos); /*/
      
        
        MagazynFIFO magazyn = new MagazynFIFO("Magazyn Testowy");

        magazyn.Umiesc(new Paczka("A", 5));
        magazyn.Umiesc(new Paczka("B", 8));
        magazyn.Umiesc(new Paczka("C", 3));

        Console.WriteLine("Bieżąca paczka: " + magazyn.PodajBiezacy());
        Console.WriteLine(magazyn);

        Paczka pobrana = magazyn.Pobierz();
        Console.WriteLine("Pobrano paczkę: " + pobrana);

        Console.WriteLine(magazyn);
    }
}
