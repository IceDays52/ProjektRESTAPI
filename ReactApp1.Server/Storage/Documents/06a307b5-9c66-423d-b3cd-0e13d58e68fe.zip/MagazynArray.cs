﻿using System;
using System.Collections.Generic;
using Zadania;

public class MagazynArray : IMagazynuje
{
    private string nazwa;
    private List<Paczka> ListaPaczek;

 
    public MagazynArray()
    {
        nazwa = "Brak nazwy";
        ListaPaczek = new List<Paczka>();
    }

    public MagazynArray(string nazwa)
    {
        this.nazwa = nazwa;
        ListaPaczek = new List<Paczka>();
    }


    public string Nazwa { get => nazwa; set => nazwa = value; }
    public int IloscPaczek => ListaPaczek.Count;

    public void Umiesc(Paczka paczka)
    {
        ListaPaczek.Add(paczka);
    }

    public Paczka Pobierz()
    {
        if (ListaPaczek.Count == 0)
            throw new InvalidOperationException("Magazyn jest pusty.");

        Paczka p = ListaPaczek[0];
        ListaPaczek.RemoveAt(0);
        return p;
    }

    public void Wyczysc()
    {
        ListaPaczek.Clear();
    }

    public int PodajIlosc()
    {
        return ListaPaczek.Count;
    }

    public Paczka PodajBiezacy()
    {
        if (ListaPaczek.Count == 0)
            throw new InvalidOperationException("Magazyn jest pusty.");

        return ListaPaczek[0];
    }

    public override string ToString()
    {
        string zawartosc = $"Magazyn Array: {nazwa}, Ilość paczek: {ListaPaczek.Count}\n";
        foreach (var p in ListaPaczek)
            zawartosc += p.ToString() + "\n";
        return zawartosc;
    }
}
