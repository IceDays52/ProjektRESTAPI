﻿using System;
using System.Collections.Generic;

namespace Zadania
{
    internal class MagazynFIFO : IMagazynuje
    {
        private string nazwa;
        private Queue<Paczka> ListaPaczek;

        public MagazynFIFO()
        {
            nazwa = "Brak nazwy";
            ListaPaczek = new Queue<Paczka>();
        }

        public MagazynFIFO(string nazwa)
        {
            this.nazwa = nazwa;
            ListaPaczek = new Queue<Paczka>();
        }

        public string Nazwa
        {
            get { return nazwa; }
            set { nazwa = value; }
        }

        public int IloscPaczek
        {
            get { return ListaPaczek.Count; }
        }

        public void Umiesc(Paczka paczka)
        {
            ListaPaczek.Enqueue(paczka);
        }

        public Paczka Pobierz()
        {
            if (ListaPaczek.Count == 0)
                throw new InvalidOperationException("Magazyn jest pusty.");

            return ListaPaczek.Dequeue();
        }

        public void Wyczysc()
        {
            ListaPaczek.Clear();
        }

        public int PodajIlosc()
        {
            return ListaPaczek.Count;
        }

        public Paczka PodajBiezacy()
        {
            if (ListaPaczek.Count == 0)
                throw new InvalidOperationException("Magazyn jest pusty.");

            return ListaPaczek.Peek();
        }

        public override string ToString()
        {
            string zawartosc = $"Magazyn FIFO: {nazwa}, Ilość paczek: {ListaPaczek.Count}\n";
            foreach (var p in ListaPaczek)
            {
                zawartosc += p.ToString() + "\n";
            }
            return zawartosc;
        }
    }
}
