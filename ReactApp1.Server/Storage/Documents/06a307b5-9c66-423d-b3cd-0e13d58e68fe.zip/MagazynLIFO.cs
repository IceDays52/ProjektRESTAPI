﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania
{
    public  class MagazynLIFO: IMagazynuje
    {
        private string nazwa;
        private int iloscPaczek;
        private Stack<Paczka> ListaPaczek;

        public MagazynLIFO()
        {
            nazwa = "Brak nazwy";
            ListaPaczek = new Stack<Paczka>();
            iloscPaczek = 0;
        }
        public MagazynLIFO(string nazwa)
        {
          this.nazwa = nazwa;
            ListaPaczek = new Stack<Paczka>();
            iloscPaczek = 0;
        }
        public string Nazwa
        {
            get { return nazwa; }
            set { nazwa = value; }
        }
        public int IloscPaczek
        {
            get { return iloscPaczek;}
        }
        public void Umiesc(Paczka t)
        {
            ListaPaczek.Push(t);
            iloscPaczek = ListaPaczek.Count;
        }
        public Paczka Pobierz()
        {
            if (ListaPaczek.Count == 0)
                return null;

            Paczka p = ListaPaczek.Pop();
            iloscPaczek = ListaPaczek.Count;
            return p;
        }
        public void Wyczysc()
        {
            ListaPaczek.Clear();
            iloscPaczek = 0;
        }

        public int PodajIlosc()
        {
            return iloscPaczek;
        }
        public Paczka PodajBiezacy()
        {
            if (ListaPaczek.Count == 0)
                return null;

            return ListaPaczek.Peek();
        }
        public override string ToString()
        {
            string zawartosc = $"Magazyn: {nazwa}, Liczba paczek: {iloscPaczek}\n";
            foreach (Paczka p in ListaPaczek)
            {
                zawartosc += p.ToString() + "\n";
            }
            return zawartosc;
        }

    }
}
