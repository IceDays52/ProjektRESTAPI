﻿using System;
namespace Zadania
{
    public class Paczka
    {

        string nadawca;
        int rozmiar;
        string numerPaczki;

        private static int liczbaPaczek;
        private static double oplataZaKg;

        static Paczka()
        {
            liczbaPaczek = 0;
            oplataZaKg = 5.0;
        }

        public Paczka()
        {
            liczbaPaczek++;
            numerPaczki = liczbaPaczek + "/2018";
            nadawca = "Nieznany";
            rozmiar = 0;
        }

        public Paczka(string nadawca, int rozmiar)
        {
            liczbaPaczek++;
            this.nadawca = nadawca;
            this.rozmiar = rozmiar;
            numerPaczki = liczbaPaczek + "/2018";
        }

        public string Nadawca
        {
            get { return nadawca; }
            set { nadawca = value; }
        }

        public int Rozmiar
        {
            get { return rozmiar; }
            set { rozmiar = value; }
        }

        public string NumerPaczki
        {
            get { return numerPaczki; }
        }

        public static int LiczbaPaczek
        {
            get { return liczbaPaczek; }
        }

        public static double OplataZaKg
        {
            get { return oplataZaKg; }
            set { oplataZaKg = value; }
        }


        public virtual double KosztWysylki()
        {
            return rozmiar * oplataZaKg;
        }


        public override string ToString()
        {
            return $"Paczka {numerPaczki}, Nadawca: {nadawca}, Rozmiar: {rozmiar}, Koszt: {KosztWysylki()} zł";
        }
    }
}