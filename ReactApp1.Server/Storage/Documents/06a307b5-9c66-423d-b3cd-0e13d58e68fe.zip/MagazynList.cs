﻿using System;
using System.Collections.Generic;
using Zadania;

public class MagazynList : IMagazynuje
{
    private string nazwa;
    private LinkedList<Paczka> ListaPaczek;

 
    public MagazynList()
    {
        nazwa = "Brak nazwy";
        ListaPaczek = new LinkedList<Paczka>();
    }

 
    public MagazynList(string nazwa)
    {
        this.nazwa = nazwa;
        ListaPaczek = new LinkedList<Paczka>();
    }


    public string Nazwa { get => nazwa; set => nazwa = value; }
    public int IloscPaczek => ListaPaczek.Count;


    public void Umiesc(Paczka paczka)
    {
        ListaPaczek.AddLast(paczka);
    }


    public Paczka Pobierz()
    {
        if (ListaPaczek.Count == 0)
            throw new InvalidOperationException("Magazyn jest pusty.");

        Paczka p = ListaPaczek.First.Value;
        ListaPaczek.RemoveFirst();
        return p;
    }


    public void Wyczysc()
    {
        ListaPaczek.Clear();
    }

    public int PodajIlosc()
    {
        return ListaPaczek.Count;
    }

    public Paczka PodajBiezacy()
    {
        if (ListaPaczek.Count == 0)
            throw new InvalidOperationException("Magazyn jest pusty.");

        return ListaPaczek.First.Value;
    }

    public override string ToString()
    {
        string zawartosc = $"Magazyn List: {nazwa}, Ilość paczek: {ListaPaczek.Count}\n";
        foreach (var p in ListaPaczek)
            zawartosc += p.ToString() + "\n";
        return zawartosc;
    }
}
